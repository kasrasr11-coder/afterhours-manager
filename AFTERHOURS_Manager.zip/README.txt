AFTERHOURS Manager
1) Python 3.10+ نصب کن.
2) pip install -r requirements.txt
3) توکن را در BOT_TOKEN قرار بده.
4) python bot.py
توکن را داخل فایل یا چت عمومی قرار نده.
